import Image from 'next/image'
import { AnimeBackground } from '@/components/anime-background'
import { CustomCursor } from '@/components/custom-cursor'
import { GlobeMap } from '@/components/globe-map'
import { Preloader } from '@/components/preloader'
import { ScrollProgress } from '@/components/scroll-progress'
import { SiteFooter } from '@/components/site-footer'
import { StaffSection } from '@/components/staff-section'

const DISCORD_URL = 'https://discord.gg/symphonyx'

const REQUIREMENTS = [
  'Быть активным на рейдах',
  'Активничать на backup',
  'Уважать каждого участника клана',
  'Быть сильным',
]

const STATS = [
  { value: 'ТОП 3', label: 'Клан СНГ' },
  { value: '30+', label: 'Рейдов' },
  { value: '24/7', label: 'Работает стафф' },
]

export default function Page() {
  return (
    <div className="relative min-h-screen overflow-x-clip rounded-xl border border-primary/20 shadow-[inset_0_0_60px_oklch(0.72_0.16_230/8%)] md:m-3">
      <Preloader />
      <CustomCursor />
      <ScrollProgress />
      <AnimeBackground />

      <header className="sticky top-0 z-40 border-b border-border bg-background/60 backdrop-blur-md">
        <nav className="mx-auto flex max-w-6xl items-center justify-between px-6 py-3">
          <a href="#top" className="flex items-center gap-3">
            <Image src="/images/synx-logo.png" alt="Логотип SynX" width={36} height={36} className="rounded-lg" />
            <span className="font-serif text-lg tracking-[0.25em] text-primary">SYNX</span>
          </a>
          <div className="flex items-center gap-6 text-sm">
            <a href="#map" className="hidden text-muted-foreground transition-colors hover:text-primary sm:block">
              Карта
            </a>
            <a href="#staff" className="hidden text-muted-foreground transition-colors hover:text-primary sm:block">
              Стафф
            </a>
            <a
              href={DISCORD_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="rounded-lg bg-primary px-4 py-2 font-semibold text-primary-foreground transition-all hover:shadow-[0_0_24px_oklch(0.72_0.16_230/60%)]"
            >
              Вступить
            </a>
          </div>
        </nav>
      </header>

      <main id="top">
        {/* Hero */}
        <section className="relative mx-auto flex max-w-6xl flex-col items-center px-6 pb-16 pt-24 text-center md:pt-32">
          <Image
            src="/images/synx-logo.png"
            alt="Эмблема клана SynX"
            width={120}
            height={120}
            priority
            className="animate-logo-pulse rounded-2xl"
          />
          <h1 className="mt-8 font-serif text-4xl text-foreground animate-glow-text md:text-6xl text-balance">
            SYNX — ТОП 3 КЛАН СНГ
          </h1>
          <p className="mt-6 max-w-2xl text-lg text-muted-foreground leading-relaxed text-pretty">
            Элитный клан по The Strongest Battlegrounds в Roblox. Мы — сила, дисциплина и полное доминирование на
            поле боя. Англичане и русские, объединённые жаждой победы.
          </p>
          <a
            href={DISCORD_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-10 rounded-xl bg-gradient-to-r from-primary to-accent px-10 py-4 font-serif text-lg text-primary-foreground transition-all duration-300 hover:scale-105 hover:shadow-[0_0_50px_oklch(0.72_0.16_230/60%)]"
          >
            Вступить в клан
          </a>

          <div className="mt-16 grid w-full max-w-3xl grid-cols-1 gap-5 sm:grid-cols-3">
            {STATS.map((s) => (
              <div
                key={s.label}
                className="rounded-xl border border-border bg-card p-6 backdrop-blur transition-all duration-300 hover:-translate-y-1 hover:border-primary/60"
              >
                <p className="font-serif text-3xl text-electric">{s.value}</p>
                <p className="mt-2 text-sm text-muted-foreground">{s.label}</p>
              </div>
            ))}
          </div>
        </section>

        <GlobeMap />

        {/* Requirements */}
        <section className="relative mx-auto max-w-6xl px-6 py-24">
          <h2 className="text-center font-serif text-3xl text-primary animate-glow-text md:text-4xl">
            Требования для вступления
          </h2>
          <ul className="mx-auto mt-10 grid max-w-3xl gap-4 sm:grid-cols-2">
            {REQUIREMENTS.map((r) => (
              <li
                key={r}
                className="flex items-center gap-4 rounded-xl border border-border bg-card p-5 backdrop-blur transition-all duration-300 hover:border-electric/60 hover:shadow-[0_0_24px_oklch(0.82_0.14_210/20%)]"
              >
                <span className="flex size-8 shrink-0 items-center justify-center rounded-full bg-primary/20 text-electric">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                    <path d="M13 2 3 14h7l-1 8 10-12h-7l1-8z" />
                  </svg>
                </span>
                <span className="text-foreground">{r}</span>
              </li>
            ))}
          </ul>
          <p className="mt-10 text-center text-muted-foreground">
            Мы принимаем людей — стафф работает 24/7.{' '}
            <a
              href={DISCORD_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="text-primary underline-offset-4 transition-all hover:underline hover:[text-shadow:0_0_14px_oklch(0.72_0.16_230/80%)]"
            >
              discord.gg/symphonyx
            </a>
          </p>
        </section>

        <StaffSection />
      </main>

      <SiteFooter />
    </div>
  )
}
